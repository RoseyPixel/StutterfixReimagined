# StutterFix 1.21.11 GitHub Build Pack

This adds GitHub Actions so your StutterFix project can build online.

## Steps

1. Extract this ZIP.
2. Copy the `.github` folder into the root of your StutterFix source project.
3. Upload the whole project to GitHub.
4. Open **Actions** and run **Build StutterFix 1.21.11**.
5. Download the generated JAR from **Artifacts**.
